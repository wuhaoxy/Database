create table trafficlight
(
    TrafficLightID char(12)                      not null comment '路段ID+方向(例:101_N)'
        primary key,
    Location       point                         not null,
    CurrentPhase   enum ('红灯', '黄灯', '绿灯') not null,
    Duration       smallint unsigned default '0' null comment '当前相位持续时间(秒)',
    NextPhase      enum ('红灯', '黄灯', '绿灯') not null,
    SegmentID      int                           not null,
    constraint trafficlight_ibfk_1
        foreign key (SegmentID) references segment (SegmentID)
            on update cascade
);

create index SegmentID
    on trafficlight (SegmentID);

create spatial index idx_light_loc
    on trafficlight (Location);

