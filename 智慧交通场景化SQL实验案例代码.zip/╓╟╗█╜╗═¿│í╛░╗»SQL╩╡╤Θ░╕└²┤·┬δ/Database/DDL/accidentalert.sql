create table accidentalert
(
    AlertID     bigint auto_increment
        primary key,
    Time        datetime                                             not null comment '精确到秒',
    Location    point                                                not null,
    Severity    enum ('轻微', '一般', '严重', '重大') default '一般' null,
    Description text                                                 null,
    SegmentID   int                                                  not null,
    VehicleID   int                                                  null comment '可为空，表示未登记车辆',
    constraint accidentalert_ibfk_1
        foreign key (SegmentID) references segment (SegmentID),
    constraint accidentalert_ibfk_2
        foreign key (VehicleID) references vehicle (VehicleID)
            on delete set null
);

create index SegmentID
    on accidentalert (SegmentID);

create index VehicleID
    on accidentalert (VehicleID);

create index idx_emergency
    on accidentalert (Time, Severity);

