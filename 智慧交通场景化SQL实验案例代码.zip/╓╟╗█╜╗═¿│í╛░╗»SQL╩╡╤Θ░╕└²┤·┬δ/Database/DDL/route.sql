create table route
(
    RouteID      smallint auto_increment
        primary key,
    RouteName    varchar(30)                   not null comment '线路名称(例:地铁2号线)',
    Direction    enum ('上行', '下行', '环线') not null,
    StartStation varchar(50)                   not null,
    EndStation   varchar(50)                   not null,
    Stops        json                          not null comment '站点列表(JSON数组格式)'
);

create index idx_route_name
    on route (RouteName);

