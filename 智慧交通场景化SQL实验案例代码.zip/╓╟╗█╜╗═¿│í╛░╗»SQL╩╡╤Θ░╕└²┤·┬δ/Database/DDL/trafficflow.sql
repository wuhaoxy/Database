create table trafficflow
(
    TrafficFlowID bigint auto_increment comment '主键'
        primary key,
    SegmentID     int                                 not null comment '关联路段',
    Time          timestamp default CURRENT_TIMESTAMP not null comment '统计时段开始时间',
    Volume        mediumint unsigned                  not null comment '车辆数',
    Speed         decimal(5, 1)                       not null comment '平均时速(km/h)',
    Status        enum ('畅通', '缓行', '拥堵')       not null,
    constraint trafficflow_ibfk_1
        foreign key (SegmentID) references segment (SegmentID)
            on delete cascade
);

create index SegmentID
    on trafficflow (SegmentID);

create index idx_time_segment
    on trafficflow (Time, SegmentID);

