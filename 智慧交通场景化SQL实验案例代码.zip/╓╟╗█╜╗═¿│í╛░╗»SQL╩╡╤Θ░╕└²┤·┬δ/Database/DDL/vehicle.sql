create table vehicle
(
    VehicleID    int auto_increment
        primary key,
    LicensePlate varchar(20)  not null comment '车牌号',
    Type         varchar(20)  not null comment '车型分类',
    Brand        varchar(30)  null comment '品牌',
    Model        varchar(50)  null comment '型号',
    Owner        varchar(100) not null comment '车主姓名/单位',
    constraint LicensePlate
        unique (LicensePlate)
);

create index idx_owner
    on vehicle (Owner(20));

