create table publictransport
(
    TransportID      char(10)           not null comment '车辆编号(例:BUS0225)'
        primary key,
    RouteID          smallint           not null,
    CurrentStop      varchar(50)        not null,
    NextStop         varchar(50)        not null,
    EstimatedArrival timestamp          null comment '下一站预计到达时间',
    Delay            smallint default 0 null comment '延误分钟数',
    constraint publictransport_ibfk_1
        foreign key (RouteID) references route (RouteID)
            on update cascade
);

create index idx_transport_route
    on publictransport (RouteID, CurrentStop);

