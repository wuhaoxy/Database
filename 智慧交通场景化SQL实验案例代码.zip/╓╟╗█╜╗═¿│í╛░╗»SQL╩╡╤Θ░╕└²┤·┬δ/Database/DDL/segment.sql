create table segment
(
    SegmentID  int auto_increment comment '路段唯一标识'
        primary key,
    RoadName   varchar(50)                                          not null comment '道路名称',
    StartPoint point                                                not null comment '起点坐标',
    EndPoint   point                                                not null comment '终点坐标',
    Length     decimal(8, 2)                                        not null comment '单位：公里',
    Direction  enum ('东', '南', '西', '北', '双向') default '双向' null,
    LaneCount  tinyint unsigned                                     not null comment '车道数量',
    check (`Length` > 0)
);

