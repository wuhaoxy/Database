# 1 查询拥堵路段
SELECT SegmentID FROM TrafficFlow
WHERE Status = '拥堵'
ORDER BY Time DESC
LIMIT 10;
# 2 查询交通流量
SELECT Time, Volume, Speed, Status
FROM TrafficFlow
WHERE SegmentID = 1001;
# 3 路段流量统计
SELECT SegmentID, AVG(Volume) AS AvgVolume
FROM TrafficFlow
GROUP BY SegmentID
ORDER BY SegmentID ASC;
# 4 分组查询
SELECT Type, COUNT(*) AS VehicleCount
FROM Vehicle
GROUP BY Type;
# 5 条件查找
SELECT RoadName, Length
FROM Segment
WHERE Direction = '南' AND LaneCount = 2;
# 6 模糊查询
SELECT SUM(Length) AS TotalLength
FROM Segment
WHERE RoadName LIKE '%街%';
# 7 范围查询
SELECT COUNT(*)
FROM AccidentAlert
WHERE ST_Contains(
  ST_GeomFromText(
    'POLYGON((106.464 29.484,106.616 29.482,106.62 29.56,106.537 29.58,106.465 29.56,106.464 29.484))'
  ),
  Location
);
# 8 信息更新
SET SQL_SAFE_UPDATES=0;
UPDATE Vehicle SET Brand = 'Toyota' WHERE Brand = '丰田';
SET SQL_SAFE_UPDATES=1;
# 9 交通流量分类
SELECT
   TrafficFlowID,
   SegmentID,
   Time,
   Volume,
   CASE
       WHEN Volume > 500 THEN '高流量'
       WHEN Volume BETWEEN 200 AND 500 THEN '中等流量'
       ELSE '低流量'
   END AS TrafficLevel,
   Speed,
   Status
FROM TrafficFlow
ORDER BY Time DESC;
# 10 公交延误
SELECT Route.RouteName, COUNT(*) AS DelayCount
FROM PublicTransport
JOIN Route ON PublicTransport.RouteID = Route.RouteID
WHERE PublicTransport.Delay > 5
GROUP BY Route.RouteName
ORDER BY DelayCount DESC;
# 11 道路事故情况
SELECT a.AlertID, a.Time, a.Location, a.Severity, a.Description, s.SegmentID, s.RoadName
FROM AccidentAlert a
JOIN Segment s ON a.SegmentID = s.SegmentID
WHERE a.Severity IN ('高', '中高')
ORDER BY a.Time DESC;
# 12 公共交通路况分析
SELECT r.RouteName, r.Direction, AVG(p.Delay) AS AvgDelay
FROM PublicTransport p
JOIN Route r ON p.RouteID = r.RouteID
GROUP BY r.RouteID
ORDER BY AvgDelay DESC;
# 13 道路事故分析
SELECT
    s.SegmentID,
    s.RoadName,
    COUNT(a.AlertID) AS TotalAccidents,
    SUM(CASE WHEN v.Type = '轿车' THEN 1 ELSE 0 END) * 100.0 / COUNT(a.AlertID) AS CarAccidentRate,
    SUM(CASE WHEN v.Type = '货车' THEN 1 ELSE 0 END) * 100.0 / COUNT(a.AlertID) AS TruckAccidentRate,
    SUM(CASE WHEN v.Type = '公交车' THEN 1 ELSE 0 END) * 100.0 / COUNT(a.AlertID) AS BusAccidentRate
FROM AccidentAlert a
JOIN Segment s ON a.SegmentID = s.SegmentID
LEFT JOIN Vehicle v ON a.VehicleID = v.VehicleID
GROUP BY s.SegmentID
ORDER BY TotalAccidents DESC
LIMIT 3;
# 14 最拥堵路段
SELECT '最拥堵路段' AS Category, s.RoadName, COUNT(*) AS CongestionCount
FROM TrafficFlow tf
JOIN Segment s ON tf.SegmentID = s.SegmentID
WHERE TIME(tf.Time) BETWEEN '07:00:00' AND '09:00:00'
  AND tf.Status = '拥堵'
GROUP BY s.RoadName
ORDER BY CongestionCount DESC
LIMIT 3;
# 15 交通事故统计
SELECT s.Direction,
       COUNT(*) AS TotalAccidents,
       AVG(CASE Severity
           WHEN '轻微' THEN 1
           WHEN '一般' THEN 2
           WHEN '严重' THEN 3
           WHEN '重大' THEN 4 END) AS SeverityLevel
FROM AccidentAlert a
JOIN Segment s ON a.SegmentID = s.SegmentID
GROUP BY s.Direction
ORDER BY TotalAccidents DESC;
# 16 公共交通信息更新
SET SQL_SAFE_UPDATES=0;
UPDATE PublicTransport p
SET p.Delay = CASE
    WHEN NOW() > p.EstimatedArrival THEN TIMESTAMPDIFF(MINUTE, p.EstimatedArrival, NOW())
    ELSE 0
END;
SET SQL_SAFE_UPDATES=1;
# 17 时空模式匹配
WITH StateSeries AS (
  SELECT
    SegmentID,
    GROUP_CONCAT(Status ORDER BY Time SEPARATOR '->') AS StatusPattern
  FROM TrafficFlow
  WHERE Time BETWEEN '2025-03-01' AND '2025-03-02'
  GROUP BY SegmentID
)
SELECT *
FROM StateSeries
WHERE StatusPattern REGEXP '拥堵.*畅通.*拥堵';
# 18 道路拥堵的分析
WITH FlowAnalysis AS (
    SELECT
        SegmentID,
        Time,
        Volume,
        Speed,
        LAG(Volume, 1) OVER (PARTITION BY SegmentID ORDER BY Time) AS Prev1Volume,
        LAG(Volume, 2) OVER (PARTITION BY SegmentID ORDER BY Time) AS Prev2Volume,
        LAG(Speed, 1) OVER (PARTITION BY SegmentID ORDER BY Time) AS Prev1Speed
    FROM TrafficFlow
)
SELECT
    SegmentID,
    Time AS CurrentTime,
    Volume AS CurrentVolume,
    Speed AS CurrentSpeed
FROM FlowAnalysis
WHERE
    Volume > Prev1Volume * 1.2
    AND Prev1Volume > Prev2Volume * 1.2
    AND Speed < Prev1Speed;
# 19 交通事故的成因分析
SELECT
    s.SegmentID,
    s.RoadName,
    COUNT(a.AlertID) AS AccidentCount,
    SUM(CASE
            WHEN t.Status = '拥堵'
            THEN TIMESTAMPDIFF(MINUTE, t.Time,
                COALESCE(
                    (SELECT MIN(Time) FROM TrafficFlow
                     WHERE SegmentID = s.SegmentID AND Time > t.Time AND Status != '拥堵'),
                    NOW()
                )
            )
        END) AS CongestionDuration
FROM TrafficFlow t
JOIN Segment s ON t.SegmentID = s.SegmentID
LEFT JOIN AccidentAlert a ON s.SegmentID = a.SegmentID AND DATE(a.Time) = '2025-3-10'
WHERE DATE(t.Time) = '2025-3-10' AND t.Status = '拥堵'
GROUP BY s.SegmentID
HAVING AccidentCount > 0;
# 20 交通健康报告
WITH FlowAnalysis AS (
    SELECT
        SegmentID,
        Time,
        Volume,
        Speed,
        LAG(Volume, 1) OVER (PARTITION BY SegmentID ORDER BY Time) AS Prev1Volume,
        LAG(Volume, 2) OVER (PARTITION BY SegmentID ORDER BY Time) AS Prev2Volume,
        LAG(Speed, 1) OVER (PARTITION BY SegmentID ORDER BY Time) AS Prev1Speed
    FROM TrafficFlow
)
SELECT
    SegmentID,
    Time AS CurrentTime,
    Volume AS CurrentVolume,
    Speed AS CurrentSpeed
FROM FlowAnalysis
WHERE
    Volume > Prev1Volume * 1.2
    AND Prev1Volume > Prev2Volume * 1.2
    AND Speed < Prev1Speed;